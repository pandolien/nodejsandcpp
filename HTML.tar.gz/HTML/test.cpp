#include <stdio.h>
#include <node.h>
#include <v8.h>
#include <iostream>
#include "lIPC.h"
namespace demo{
	using v8::FunctionCallbackInfo;
	using v8::Isolate;
	using v8::Local;
	using v8::Object;
	using v8::String;
	using v8::Number;
	using v8::Context;
	using v8::Value;
	using v8::Array;
	void Method1(const FunctionCallbackInfo<Value>& args){
		lIPC lipc;
		Isolate* isolate = args.GetIsolate();
		//if(args.Length() != 2){return;}
		int x = 200;
		v8::Local<v8::Number> total = Number::New(isolate,x);
		args.GetReturnValue().Set(total);
	}
	void IKFunction(const FunctionCallbackInfo<Value>& args){
		Isolate* isolate = args.GetIsolate();
		lIPC lipc;
		lipc.Connect('R',100);
		if(args.Length() != 2){return;}

		Local<Context> context = isolate->GetCurrentContext();
		Local<Number> Nv = Local<Number>::Cast(args[0]);
		Local<Number> Nw = Local<Number>::Cast(args[1]);
		float v = static_cast<float>(Nv->Value());
		float w = static_cast<float>(Nw->Value());
		printf("%f,%f\n",v,w);
		lipc.SetData(0,&v,sizeof(float));
		lipc.SetData(4,&w,sizeof(float));
	}
	void PositionX(const FunctionCallbackInfo<Value>& args){
		Isolate* isolate = args.GetIsolate();
		lIPC lipc;
		lipc.Connect('W',100);
		float x,y,q;
		memmove(&x,&lipc.Buf[4],sizeof(float));
		Local<Number> arr = Number::New(isolate,x);
		args.GetReturnValue().Set(arr);
	}
	void PositionY(const FunctionCallbackInfo<Value>& args){
		Isolate* isolate = args.GetIsolate();
		lIPC lipc;
		lipc.Connect('W',100);
		float x,y,q;
		memmove(&y,&lipc.Buf[8],sizeof(float));
		Local<Number> arr = Number::New(isolate,y);
		args.GetReturnValue().Set(arr);
	}
	void PositionQ(const FunctionCallbackInfo<Value>& args){
		Isolate* isolate = args.GetIsolate();
		lIPC lipc;
		lipc.Connect('W',100);
		float x,y,q;
		memmove(&q,&lipc.Buf[12],sizeof(float));
		Local<Number> arr = Number::New(isolate,q);
		args.GetReturnValue().Set(arr);
	}
	void init(Local<Object> exports) { 
		NODE_SET_METHOD(exports, "test1", Method1);
		NODE_SET_METHOD(exports, "IK", IKFunction);
		NODE_SET_METHOD(exports, "PositionX", PositionX);
		NODE_SET_METHOD(exports, "PositionY", PositionY);
		NODE_SET_METHOD(exports, "PositionQ", PositionQ);
	}
	NODE_MODULE(addon, init)
}
