const test = require('./build/Release/hangleModule.node')
const express = require('express');
const app = express();
const path = require('path');

app.use(express.static(path.join(__dirname, 'public')));

// 라우트를 설정합니다.
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'test2.html')); // index.html 파일을 보냅니다.
});

app.get('/button1', (req, res) => {
  const data = {
  	value: 10
  };
  test.IK(10,0);
  res.json(data);
});

app.get('/button2', (req, res) => {
  const data = {
  	value: -10
  };
  test.IK(-10,0);
  res.json(data);
});

app.get('/button3', (req, res) => {
  const data = {
  	value: 10
  };
  
  test.IK(0,10);
  res.json(data);
});

app.get('/button4', (req, res) => {
  const data = {
  	value: -10
  };
  test.IK(0,-10);
  res.json(data);
});

app.get('/Timer', (req, res) => {
	const data = {
	  	x: test.PositionX(),
	  	y: test.PositionY(),
	  	q: test.PositionQ()
	};
  	res.json(data);
});
// 서버를 3000번 포트에서 실행합니다.
app.listen(3000, () => {
  console.log('서버가 3000번 포트에서 실행 중입니다.');
});

