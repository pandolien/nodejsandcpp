#ifndef __CMainWin_H__
#define __CMainWin_H__
#include <stdio.h>
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QTimer>
#include <QDebug>

#include "lIPC.h"

class CMainWin: public QWidget{
public:
	CMainWin(QWidget *parent = NULL):QWidget(parent){
		Initialzatoin();
		Init();
	}
public:
	void Initialzatoin();
	void Init();
	void closeEvent(QCloseEvent *event)override{
		lipcR.Close();
		lipcW.Close();
		timer->stop();
		printf("Close\n");
	}
private:
	QPushButton *btSave;
	QLineEdit *xEdit,*yEdit,*qEdit;
	QLabel *vText,*wText;
	QTimer *timer;
public:
	lIPC lipcR;
	lIPC lipcW;
public:
	float x,y,q;
	float v,w;

public:
	void btSaveClick();
	void Timer();
};

#endif
