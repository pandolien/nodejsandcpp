#ifndef __LIPC_H__
#define __LIPC_H__

#include <sys/ipc.h>
#include <sys/shm.h>
typedef unsigned char BYTE;
class lIPC{
	public:
		lIPC();
		virtual ~lIPC();
	public:
		void Initialzation();
		void Init(char,int);
		void Connect(char,int);
		void Close();
	public:
		key_t Key;
		int shmid;
		BYTE *Buf;
		bool Error;
		int n;
	public:
		bool SetData(int,void*,int);
		bool BuffClear(int,int);
};
#endif
