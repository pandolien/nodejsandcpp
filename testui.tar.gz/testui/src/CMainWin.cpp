#include "CMainWin.h"

void CMainWin::Initialzatoin(){
	btSave = NULL;
	xEdit = NULL;
	yEdit = NULL;
	qEdit = NULL;
	vText = NULL;
	wText = NULL;
	timer = NULL;
	v = 0;
	w = 0;
}
void CMainWin::Init(){
	btSave = new QPushButton("Save",this);
	xEdit = new QLineEdit("0.000000",this);
	yEdit = new QLineEdit("0.000000",this);
	qEdit = new QLineEdit("0.000000",this);
	vText = new QLabel("0.000000",this);
	wText = new QLabel("0.000000",this);
	timer = new QTimer(this);
	
	btSave->setGeometry(100,100,160,30);
	xEdit->setGeometry(0,0,100,30);
	yEdit->setGeometry(0,30,100,30);
	qEdit->setGeometry(0,60,100,30);
	vText->setGeometry(100,0,100,30);
	wText->setGeometry(100,30,100,30);
	
	timer->start(100);
	
	lipcR.Init('R',100);
	lipcW.Init('W',100);
	
	connect(timer,&QTimer::timeout,this,&CMainWin::Timer);
	connect(btSave,&QPushButton::clicked,this,&CMainWin::btSaveClick);
}

void CMainWin::btSaveClick(){
	QString X,Y,Q;
	X = xEdit->text();
	Y = yEdit->text();
	Q = qEdit->text();
	this->x = X.toFloat();
	this->y = Y.toFloat();
	this->q = Q.toFloat();
	lipcW.SetData(0,&x,sizeof(float));
	lipcW.SetData(4,&y,sizeof(float));
	lipcW.SetData(8,&q,sizeof(float));
	printf("Location :\n\t%f\t%f\t%f\n",this->x,this->y,this->q);
}
void CMainWin::Timer(){
	char buf[100];
	memmove(&this->v,&this->lipcR.Buf[4],sizeof(float));
	memmove(&this->w,&this->lipcR.Buf[8],sizeof(float));
	
	memset(buf,0,sizeof(char)*100);
	sprintf(buf,"%f",this->v);
	vText->setText(buf);
	memset(buf,0,sizeof(char)*100);
	sprintf(buf,"%f",this->w);
	wText->setText(buf);

}
