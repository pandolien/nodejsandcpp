#include "lIPC.h"
#include <stdio.h>
#include <string.h>

lIPC::lIPC(){
	Initialzation();
}
lIPC::~lIPC(){
	Close();
}
void lIPC::Initialzation(){
	Key = -1;
	n = -1;
	Buf = NULL;
	Error = false;
}
void lIPC::Init(char ID,int n){
	Close();
	Key = ftok("/tmp",ID);
	shmid = shmget(Key,n+sizeof(int),IPC_CREAT | 0666);
	if(shmid < 0) {
		printf("Error\n");
		Error = true;
		return;
	}
	Buf = (BYTE*)shmat(shmid,0,0);
	this->n = n;
	memmove(Buf,&n,sizeof(int));
}
void lIPC::Connect(char ID,int n){
	Close();
	Key = ftok("/tmp",ID);
	shmid = shmget(Key,n+sizeof(int),0666);
	if(shmid < 0) {
		printf("Error\n");
		Error = true;
		return;
	}
	Buf = (BYTE*)shmat(shmid,0,0);
	memmove(&this->n,Buf,sizeof(int));
	
}
void lIPC::Close(){
	if(Buf){shmdt(Buf);}	
	shmid = -1;
	n = -1;
}
bool lIPC::SetData(int n,void* D,int size){
	if(n < 0)		return false;
	if(n+size > this->n)	return false;
	if(Error)		return false;
	BYTE *Buff = &Buf[4]; 
	memmove(&Buff[n],D,size);
	return true;
}
bool lIPC::BuffClear(int s,int size){
	if(s < 0) 	return false;
	if(n < s+size)	return false;
	if(Error)	return false;
	BYTE *Buff = &Buf[4];
	memset(&Buff[s],0,sizeof(BYTE)*size);
	return true;
}
