#include <QApplication>
#include <stdio.h>
#include <string.h>
#include "CMainWin.h"
int main(int argc,char *argv[]){
	QApplication a(argc, argv);
	CMainWin window;
	
	window.show();
	return a.exec();
}
